import { Badge } from "../ui/badge";
import { Button } from "../ui/button";
import { Heart, Clock, Users, Star } from "lucide-react";

export interface ExperiencePreview {
  coverImage: string;
  category: string;
  location: string;
  rating: number;
  reviewCount: number;
  title: string;
  hostName: string;
  hostAvatar: string;
  hostVerified: boolean;
  duration: number; // in hours
  capacity: number;
  tags: string[];
  price: number;
}

interface Props {
  experience: ExperiencePreview;
  onEdit?: () => void;
  onPublish?: () => void;
}

export function ExperiencePreviewCard({ experience, onEdit, onPublish }: Props) {
  return (
    <div className="w-full max-w-sm bg-card rounded-lg overflow-hidden border hover:shadow-lg transition-shadow">
      {/* Cover Image */}
      <div className="relative aspect-[4/3] overflow-hidden group">
        <img 
          src={experience.coverImage} 
          alt={experience.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
        
        {/* Category Badge */}
        <div className="absolute top-3 left-3">
          <Badge variant="secondary" className="bg-white/90 backdrop-blur-sm">
            {experience.category}
          </Badge>
        </div>

        {/* Favorite Icon */}
        <button className="absolute top-3 right-3 size-9 rounded-full bg-white/90 backdrop-blur-sm flex items-center justify-center hover:bg-white transition-colors">
          <Heart className="size-5" />
        </button>
      </div>

      {/* Content */}
      <div className="p-4 space-y-3">
        {/* Location & Rating */}
        <div className="flex items-center justify-between text-sm">
          <span className="text-muted-foreground">{experience.location}</span>
          <div className="flex items-center gap-1">
            <Star className="size-4 fill-yellow-500 text-yellow-500" />
            <span className="font-medium">{experience.rating.toFixed(1)}</span>
            <span className="text-muted-foreground">({experience.reviewCount})</span>
          </div>
        </div>

        {/* Title */}
        <h3 className="line-clamp-2 leading-snug">
          {experience.title}
        </h3>

        {/* Host */}
        <div className="flex items-center gap-2">
          <img 
            src={experience.hostAvatar} 
            alt={experience.hostName}
            className="size-6 rounded-full"
          />
          <span className="text-sm">{experience.hostName}</span>
          {experience.hostVerified && (
            <svg className="size-4 text-blue-500" viewBox="0 0 16 16" fill="currentColor">
              <path d="M8 0L10.5 2.5L14 3L11.5 6L12 9.5L8 7.5L4 9.5L4.5 6L2 3L5.5 2.5L8 0Z" />
              <path d="M6.5 7.5L7.5 8.5L9.5 6.5" stroke="white" strokeWidth="1.5" fill="none" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          )}
        </div>

        {/* Duration & Capacity */}
        <div className="flex items-center gap-4 text-sm text-muted-foreground">
          <div className="flex items-center gap-1.5">
            <Clock className="size-4" />
            <span>{experience.duration} hours</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Users className="size-4" />
            <span>{experience.capacity} people</span>
          </div>
        </div>

        {/* Tags */}
        <div className="flex flex-wrap gap-2">
          {experience.tags.slice(0, 3).map((tag, idx) => (
            <span key={idx} className="text-xs px-2 py-1 bg-muted rounded-md">
              {tag}
            </span>
          ))}
        </div>

        {/* Price & Action */}
        <div className="flex items-center justify-between pt-2 border-t">
          <div>
            <div className="flex items-baseline gap-1">
              <span className="text-xl">₹{experience.price.toLocaleString()}</span>
              <span className="text-sm text-muted-foreground">per person</span>
            </div>
          </div>
          {onPublish && onEdit ? (
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={onEdit}>
                Edit
              </Button>
              <Button size="sm" onClick={onPublish}>
                Publish
              </Button>
            </div>
          ) : (
            <Button size="sm" className="bg-destructive hover:bg-destructive/90">
              Book now
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
