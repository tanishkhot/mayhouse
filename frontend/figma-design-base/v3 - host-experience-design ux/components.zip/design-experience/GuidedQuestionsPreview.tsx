import { useState } from "react";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import { ExperiencePreviewCard, ExperiencePreview } from "./ExperiencePreviewCard";
import { Sparkles, ArrowLeft, CheckCircle2 } from "lucide-react";
import { ExperienceFormState } from "./types";

interface Props {
  onComplete: (draftData: Partial<ExperienceFormState>) => void;
  onBack: () => void;
}

export function GuidedQuestionsPreview({ onComplete, onBack }: Props) {
  const [isGenerating, setIsGenerating] = useState(false);
  const [showPreview, setShowPreview] = useState(false);

  // Mock experience preview data (would come from AI processing the Q&A answers)
  const mockPreview: ExperiencePreview = {
    coverImage: "https://images.unsplash.com/photo-1524492412937-b28074a5d7da?w=800&q=80",
    category: "Culture",
    location: "Gandhi Bazaar, Bangalore",
    rating: 4.9,
    reviewCount: 127,
    title: "Hidden Stories of the Gothic Quarter",
    hostName: "Maria Garcia",
    hostAvatar: "https://i.pravatar.cc/150?img=1",
    hostVerified: true,
    duration: 3,
    capacity: 6,
    tags: ["History", "Walking", "Local insights"],
    price: 1500
  };

  const handleSimulateCompletion = async () => {
    setIsGenerating(true);
    
    // Simulate AI processing time
    await new Promise(resolve => setTimeout(resolve, 2500));
    
    setIsGenerating(false);
    setShowPreview(true);
  };

  const handleEdit = () => {
    // Convert preview to form state
    const draftData: Partial<ExperienceFormState> = {
      title: mockPreview.title,
      description: "Experience the soul of old Bangalore as we walk through the historic Gandhi Bazaar neighborhood during golden hour. Discover century-old spice merchants, family-run sweet shops, and hidden temples that locals cherish. This isn't just a tour—it's an intimate journey through stories, flavors, and the living heritage of South Bangalore.",
      category: mockPreview.category,
      duration: mockPreview.duration * 60,
      capacity: mockPreview.capacity,
      neighborhood: mockPreview.location,
      basePrice: mockPreview.price,
      coverImage: mockPreview.coverImage,
      qualityScore: 78,
    };
    
    onComplete(draftData);
  };

  const handlePublishDirect = () => {
    // Could go straight to review step
    handleEdit();
  };

  if (!showPreview) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background p-6">
        <div className="max-w-2xl w-full space-y-8">
          {/* Header */}
          <div className="space-y-2">
            <Button 
              variant="ghost" 
              onClick={onBack}
              className="mb-2"
            >
              ← Back
            </Button>
            <h2>Let's Build Together</h2>
            <p className="text-muted-foreground">
              We'll guide you through a series of questions to create your perfect experience listing.
            </p>
          </div>

          {/* Info */}
          <div className="space-y-4">
            <div className="p-6 bg-muted/30 rounded-lg space-y-4">
              <h4>📝 What to expect</h4>
              <ul className="space-y-3 text-sm text-muted-foreground">
                <li className="flex items-start gap-3">
                  <CheckCircle2 className="size-5 text-primary flex-shrink-0 mt-0.5" />
                  <span><strong>8 guided questions</strong> covering your experience details, story, logistics, and safety</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircle2 className="size-5 text-primary flex-shrink-0 mt-0.5" />
                  <span><strong>AI-powered</strong> extraction of key details from your natural language answers</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircle2 className="size-5 text-primary flex-shrink-0 mt-0.5" />
                  <span><strong>Preview your listing</strong> before publishing to see how travelers will see it</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircle2 className="size-5 text-primary flex-shrink-0 mt-0.5" />
                  <span><strong>Takes ~10-15 minutes</strong> to complete with thoughtful answers</span>
                </li>
              </ul>
            </div>

            <div className="p-4 bg-blue-50 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-900 rounded-lg">
              <p className="text-sm text-blue-700 dark:text-blue-400">
                💡 <strong>Tip:</strong> Be descriptive and authentic. The more detail you provide, the better your listing will be. Share your story, your passion, and what makes your experience unique.
              </p>
            </div>
          </div>

          {/* Action */}
          <div className="flex gap-3">
            <Button
              onClick={handleSimulateCompletion}
              disabled={isGenerating}
              className="flex-1"
              size="lg"
            >
              {isGenerating ? (
                <>
                  <Sparkles className="size-5 mr-2 animate-pulse" />
                  Creating Your Experience...
                </>
              ) : (
                <>
                  <Sparkles className="size-5 mr-2" />
                  Start Guided Questions
                </>
              )}
            </Button>
          </div>

          {isGenerating && (
            <div className="space-y-3">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Processing your answers...</span>
                <span className="text-primary">85%</span>
              </div>
              <div className="h-2 bg-muted rounded-full overflow-hidden">
                <div className="h-full bg-primary rounded-full animate-pulse" style={{ width: '85%' }} />
              </div>
              <div className="grid grid-cols-2 gap-3 text-xs text-muted-foreground">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="size-4 text-green-600" />
                  <span>Extracted title & description</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="size-4 text-green-600" />
                  <span>Identified meeting point</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="size-4 text-green-600" />
                  <span>Categorized experience domain</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="size-4 border-2 border-primary border-t-transparent rounded-full animate-spin" />
                  <span>Generating preview...</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="flex items-center justify-center min-h-screen bg-background p-6">
      <div className="max-w-4xl w-full space-y-8">
        {/* Header */}
        <div className="text-center space-y-3">
          <div className="inline-flex items-center justify-center size-14 rounded-full bg-green-100 dark:bg-green-950/30 mb-2">
            <CheckCircle2 className="size-7 text-green-600" />
          </div>
          <h2>Your Experience Preview</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Here's how travelers will see your experience on Mayhouse. You can edit details or publish it for review.
          </p>
        </div>

        {/* Preview Cards Layout */}
        <div className="grid md:grid-cols-2 gap-8 items-start">
          {/* Main Preview */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3>Listing Preview</h3>
              <Badge variant="secondary" className="gap-1">
                <Sparkles className="size-3" />
                AI Generated
              </Badge>
            </div>
            <ExperiencePreviewCard 
              experience={mockPreview}
              onEdit={handleEdit}
              onPublish={handlePublishDirect}
            />
          </div>

          {/* Details Summary */}
          <div className="space-y-4">
            <h3>What We Extracted</h3>
            
            <div className="space-y-3 p-4 bg-card border rounded-lg">
              <DetailItem 
                label="Title" 
                value={mockPreview.title}
                confidence={92}
              />
              <DetailItem 
                label="Category" 
                value={mockPreview.category}
                confidence={88}
              />
              <DetailItem 
                label="Location" 
                value={mockPreview.location}
                confidence={95}
              />
              <DetailItem 
                label="Duration" 
                value={`${mockPreview.duration} hours`}
                confidence={100}
              />
              <DetailItem 
                label="Capacity" 
                value={`${mockPreview.capacity} people`}
                confidence={100}
              />
              <DetailItem 
                label="Price" 
                value={`₹${mockPreview.price.toLocaleString()}`}
                confidence={100}
              />
              <DetailItem 
                label="Tags" 
                value={mockPreview.tags.join(", ")}
                confidence={85}
              />
            </div>

            <div className="p-4 bg-muted/30 rounded-lg space-y-2">
              <h4>Next Steps</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex items-start gap-2">
                  <span className="text-primary">•</span>
                  <span><strong>Edit:</strong> Fine-tune any details in the full editor</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary">•</span>
                  <span><strong>Publish:</strong> Submit for Mayhouse review (48h turnaround)</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary">•</span>
                  <span>Add photos, route details, and schedule slots after approval</span>
                </li>
              </ul>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex justify-center gap-3 pt-6 border-t">
          <Button variant="outline" onClick={onBack}>
            <ArrowLeft className="size-4 mr-2" />
            Start Over
          </Button>
          <Button variant="outline" size="lg" onClick={handleEdit}>
            Edit Details
          </Button>
          <Button size="lg" onClick={handlePublishDirect}>
            Continue to Publish
          </Button>
        </div>
      </div>
    </div>
  );
}

function DetailItem({ 
  label, 
  value, 
  confidence 
}: { 
  label: string; 
  value: string; 
  confidence: number;
}) {
  return (
    <div className="flex items-start justify-between gap-4 py-2 border-b last:border-0">
      <div className="flex-1">
        <p className="text-xs text-muted-foreground mb-0.5">{label}</p>
        <p className="text-sm">{value}</p>
      </div>
      <Badge 
        variant="secondary" 
        className={`text-xs ${
          confidence >= 90 ? "bg-green-100 text-green-700 dark:bg-green-950/30 dark:text-green-400" :
          confidence >= 80 ? "bg-blue-100 text-blue-700 dark:bg-blue-950/30 dark:text-blue-400" :
          "bg-yellow-100 text-yellow-700 dark:bg-yellow-950/30 dark:text-yellow-400"
        }`}
      >
        {confidence}%
      </Badge>
    </div>
  );
}