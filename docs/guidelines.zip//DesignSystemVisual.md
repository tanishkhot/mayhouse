# Mayhouse Design System Visual Reference

## Color Token Hierarchy

```
┌─────────────────────────────────────────────────────────────────────────┐
│                        MAYHOUSE COLOR SYSTEM                            │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  SURFACES                          CONTENT                             │
│  ┌─────────────────┐               ┌─────────────────┐                 │
│  │ background      │ #ffffff       │ foreground      │ #030213         │
│  │ (page canvas)   │ ───────►      │ (primary text)  │                 │
│  └─────────────────┘               └─────────────────┘                 │
│                                                                         │
│  ┌─────────────────┐               ┌─────────────────┐                 │
│  │ card            │ #ffffff       │ muted-foreground│ #717182         │
│  │ (containers)    │ ───────►      │ (secondary text)│                 │
│  └─────────────────┘               └─────────────────┘                 │
│                                                                         │
│  ┌─────────────────┐               ┌─────────────────┐                 │
│  │ accent          │ #e9ebef       │ accent-fg       │ #030213         │
│  │ (hover states)  │ ───────►      │                 │                 │
│  └─────────────────┘               └─────────────────┘                 │
│                                                                         │
│  ┌─────────────────┐               ┌─────────────────┐                 │
│  │ muted           │ #ececf0       │ border          │ rgba(0,0,0,0.1) │
│  │ (disabled)      │               │ (dividers)      │                 │
│  └─────────────────┘               └─────────────────┘                 │
│                                                                         │
│  INTERACTIVE                       STATUS                              │
│  ┌─────────────────┐               ┌─────────────────┐                 │
│  │ primary         │ #030213       │ chart-1         │ oklch(orange)   │
│  │ (CTAs)          │ ───────►      │ (ratings, trust)│                 │
│  │                 │   hover:90%   └─────────────────┘                 │
│  └─────────────────┘                                                   │
│                                    ┌─────────────────┐                 │
│  ┌─────────────────┐               │ destructive     │ #d4183d         │
│  │ primary-fg      │ #ffffff       │ (errors, delete)│                 │
│  │ (CTA text)      │               └─────────────────┘                 │
│  └─────────────────┘                                                   │
│                                                                         │
│  DARK MODE: All tokens auto-adapt via CSS variables                    │
│  ─────────────────────────────────────────────────────────────────────  │
│  background: #ffffff → oklch(0.145 0 0) (near-black)                   │
│  foreground: #030213 → oklch(0.985 0 0) (near-white)                   │
│  primary:    #030213 → oklch(0.985 0 0) (inverted)                     │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## Component State Matrix

```
┌───────────────────┬──────────────┬──────────────┬──────────────┬──────────────┐
│ COMPONENT         │ DEFAULT      │ HOVER        │ ACTIVE       │ FOCUS        │
├───────────────────┼──────────────┼──────────────┼──────────────┼──────────────┤
│ Primary Button    │ bg-primary   │ bg-primary/  │ scale-95     │ ring-ring/50 │
│                   │ text-primary │ 90           │ (100ms)      │ ring-[3px]   │
│                   │ -foreground  │ (300ms)      │              │              │
├───────────────────┼──────────────┼──────────────┼──────────────┼──────────────┤
│ Outline Button    │ border       │ bg-accent    │ scale-95     │ ring-ring/50 │
│                   │ bg-card      │ border-ring  │              │              │
├───────────────────┼──────────────┼──────────────┼──────────────┼──────────────┤
│ Date Selector     │ bg-card      │ bg-accent    │ scale-95     │ ring-ring/50 │
│ (available)       │ border       │ border-ring  │              │              │
├───────────────────┼──────────────┼──────────────┼──────────────┼──────────────┤
│ Date Selector     │ bg-primary   │ -            │ -            │ ring-ring/50 │
│ (selected)        │ text-primary │              │              │              │
│                   │ -foreground  │              │              │              │
├───────────────────┼──────────────┼──────────────┼──────────────┼──────────────┤
│ Date Selector     │ bg-muted     │ -            │ -            │ -            │
│ (disabled)        │ text-muted   │ cursor-not-  │              │              │
│                   │ -foreground  │ allowed      │              │              │
├───────────────────┼──────────────┼──────────────┼──────────────┼──────────────┤
│ Experience Card   │ bg-card      │ shadow-xl    │ -            │ -            │
│                   │ border       │ border-ring  │              │              │
├───────────────────┼──────────────┼──────────────┼──────────────┼──────────────┤
│ Icon Button       │ transparent  │ bg-accent    │ scale-95     │ ring-ring/50 │
├───────────────────┼──────────────┼──────────────┼──────────────┼──────────────┤
│ Link              │ text-        │ text-primary │ -            │ underline    │
│                   │ foreground   │              │              │              │
├───────────────────┼──────────────┼──────────────┼──────────────┼──────────────┤
│ Badge (default)   │ bg-primary   │ -            │ -            │ -            │
│                   │ text-primary │              │              │              │
│                   │ -foreground  │              │              │              │
├───────────────────┼──────────────┼──────────────┼──────────────┼──────────────┤
│ Badge (outline)   │ border       │ bg-accent    │ -            │ -            │
│                   │ text-        │              │              │              │
│                   │ foreground   │              │              │              │
└───────────────────┴──────────────┴──────────────┴──────────────┴──────────────┘
```

---

## Experience Detail Page Layout

```
┌─────────────────────────────────────────────────────────────────────────┐
│ STICKY HEADER                                                    [X]    │
│ bg-background/95 backdrop-blur-sm                        [Share][Heart] │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│ ╔═══════════════════════════════════════════════════════════════════╗   │
│ ║                                                                   ║   │
│ ║                    HERO IMAGE GALLERY                             ║   │
│ ║              aspect-[21/9] · rounded-3xl                          ║   │
│ ║                                                                   ║   │
│ ║  [◄]                                                        [►]   ║   │
│ ║                        [● ○ ○]                                    ║   │
│ ╚═══════════════════════════════════════════════════════════════════╝   │
│                                                                         │
│  ┌─────────────────────────────────────────┐  ┌───────────────────┐    │
│  │ [Badge] Category                        │  │ BOOKING SIDEBAR   │    │
│  │                                         │  │ (sticky top-24)   │    │
│  │ Hidden Stories of the Gothic Quarter   │  │                   │    │
│  │ ★ 4.9 (127) · Barcelona, Spain          │  │ $45 per person    │    │
│  │                                         │  │ ───────────────   │    │
│  │ [3h] [6-8 people] [3 spots left]        │  │                   │    │
│  │                                         │  │ Select a date:    │    │
│  ├─────────────────────────────────────────┤  │ [Date 1]          │    │
│  │ ┌───────────────────────────────────┐   │  │ [Date 2] ✓        │    │
│  │ │ [Avatar] Maria Garcia ✓            │   │  │ [Date 3]          │    │
│  │ │ Local historian · Host since 2022  │   │  │                   │    │
│  │ │ I've lived in Barcelona's Gothic...│   │  │ Available times:  │    │
│  │ │ [View full profile →]              │   │  │ [10AM] [2PM] ✓    │    │
│  │ └───────────────────────────────────┘   │  │ [4PM]             │    │
│  │                                         │  │ ───────────────   │    │
│  ├─────────────────────────────────────────┤  │                   │    │
│  │ What you'll experience                  │  │ [Reserve Spot →]  │    │
│  │ ───────────────────────────────────     │  │                   │    │
│  │ Forget the typical tourist trails...   │  │ 20% stake held    │    │
│  │                                         │  │ in escrow         │    │
│  │                                         │  │                   │    │
│  ├─────────────────────────────────────────┤  │ ✓ Full refund     │    │
│  │ Experience Timeline                     │  │ ✓ Verified host   │    │
│  │ ───────────────────────────────────     │  │ ✓ Secure escrow   │    │
│  │ ① 0:00 Meet at Plaça Sant Jaume        │  └───────────────────┘    │
│  │ ② 0:30 Hidden Roman ruins               │                          │
│  │ ③ 1:30 Traditional café break           │                          │
│  │ ④ 2:15 Secret courtyards                │                          │
│  │                                         │                          │
│  ├─────────────────────────────────────────┤                          │
│  │ What's Included                         │                          │
│  │ ───────────────────────────────────     │                          │
│  │ ✓ 3-hour guided walk                    │                          │
│  │ ✓ Traditional Catalan snack             │                          │
│  │ ✓ Digital guide                         │                          │
│  │ ✓ Blockchain proof token                │                          │
│  │                                         │                          │
│  ├─────────────────────────────────────────┤                          │
│  │ Meeting Point                           │                          │
│  │ ───────────────────────────────────     │                          │
│  │ 📍 Plaça Sant Jaume, Barcelona          │                          │
│  │ [Open in maps →]                        │                          │
│  │                                         │                          │
│  ├─────────────────────────────────────────┤                          │
│  │ Guest Reviews                           │                          │
│  │ ───────────────────────────────────     │                          │
│  │ ★ 4.9 · 127 reviews                     │                          │
│  │                                         │                          │
│  │ ┌───────────────────────────────────┐   │                          │
│  │ │ [Avatar] Sarah Chen  · 2 weeks ago│   │                          │
│  │ │ ★★★★★                             │   │                          │
│  │ │ This wasn't just a tour—it was... │   │                          │
│  │ └───────────────────────────────────┘   │                          │
│  │ [... 2 more reviews]                    │                          │
│  │                                         │                          │
│  │ [Show all 127 reviews]                  │                          │
│  └─────────────────────────────────────────┘                          │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘

MOBILE VERSION:
┌─────────────────────────────────────┐
│ [X]                  [Share][Heart] │ ← Sticky header
├─────────────────────────────────────┤
│ [    Hero Image (4:3 aspect)    ]  │
│                                     │
│ [Badge] Gothic Quarter              │
│ ★ 4.9 · Barcelona                   │
│                                     │
│ [Host Card]                         │
│ What you'll experience...           │
│ Timeline...                         │
│ What's included...                  │
│ Meeting point...                    │
│ Reviews...                          │
│                                     │
│                                     │
│                                     │
├─────────────────────────────────────┤
│ $45      [Reserve Spot →]          │ ← Fixed bottom CTA
└─────────────────────────────────────┘  (appears on scroll)
```

---

## Transition Sequence Visual

```
CARD STATE (Explore Page)                DETAIL STATE (Detail Page)
t=0ms                                    t=700ms

┌──────────────────────┐                 ╔════════════════════════════════╗
│ ┌──────────────┐     │                 ║                                ║
│ │  [Image]     │     │                 ║     [Expanded Hero Image]      ║
│ │  400x300     │ ────┼─────────────────▶                                ║
│ └──────────────┘     │   Scale +       ║         1200x512               ║
│ Gothic Quarter       │   Translate     ╚════════════════════════════════╝
│ ★ 4.9 · Barcelona    │   300ms         
│ 3h · 6-8 people      │                 Gothic Quarter Experience
│ $45  [Book Now]      │                 ★ 4.9 (127 reviews) · Barcelona
└──────────────────────┘                 [3h] [6-8 people] [3 spots left]
                                         
opacity: 1 → 0.95 → 0                    [Host Card] ← Fade in delay 300ms
                                         [Details]   ← Fade in delay 350ms
                                         [Sidebar]   ← Fade in delay 400ms

ANIMATION SEQUENCE:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
0ms       150ms     300ms     450ms     600ms     700ms
│         │         │         │         │         │
Card      │█████████│         │         │         │ Fade out
Click     │         │         │         │         │
          │         │         │         │         │
Hero      │         │██████████         │         │ Expand + fade in
Image     │         │         │         │         │
          │         │         │         │         │
Header    │         │         │██████████         │ Slide up + fade
(Title)   │         │         │         │         │
          │         │         │         │         │
Host      │         │         │         │█████████│ Slide up + fade
Card      │         │         │         │         │
          │         │         │         │         │
Details   │         │         │         │         │█████████ Slide + fade
          │         │         │         │         │
Sidebar   │         │         │         │         │█████████ Slide + fade
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## Interactive Element Anatomy

### Primary CTA Button

```
┌──────────────────────────────────────────────────────────────┐
│                     RESERVE YOUR SPOT                         │
│                                                               │
│  ┌────────────────────────────────────────────────────────┐  │
│  │ BASE LAYER                                             │  │
│  │ • bg-primary (#030213 light / #fcfcfc dark)           │  │
│  │ • text-primary-foreground (white / black)             │  │
│  │ • h-10 (40px) · rounded-md · px-6                     │  │
│  └────────────────────────────────────────────────────────┘  │
│                                                               │
│  HOVER (300ms ease-out)                                       │
│  • bg-primary/90 (10% lighter)                                │
│  • cursor-pointer                                             │
│                                                               │
│  ACTIVE (100ms ease-in)                                       │
│  • transform: scale(0.95)                                     │
│  • Micro-compression feel                                     │
│                                                               │
│  FOCUS-VISIBLE (keyboard navigation)                          │
│  • outline: none                                              │
│  • ring-[3px] ring-ring/50                                    │
│  • Blue glow around button                                    │
│                                                               │
│  DISABLED                                                     │
│  • opacity-50                                                 │
│  • pointer-events-none                                        │
│  • cursor-not-allowed                                         │
│                                                               │
└──────────────────────────────────────────────────────────────┘
```

### Date Selector Card

```
DEFAULT STATE                   HOVER STATE
┌──────────────────────┐        ┌──────────────────────┐
│ Wed, Jan 15          │   →    │ Wed, Jan 15          │
│                      │        │                      │
│ bg-card              │        │ bg-accent            │
│ border-border        │        │ border-ring          │
│ text-foreground      │        │ scale: 1.0           │
└──────────────────────┘        └──────────────────────┘
                                    ▲ transition 300ms

SELECTED STATE                  DISABLED STATE
┌──────────────────────┐        ┌──────────────────────┐
│ Wed, Jan 15  ✓       │        │ Sat, Jan 25          │
│                      │        │ Sold out             │
│ bg-primary           │        │ bg-muted             │
│ text-primary-fg      │        │ text-muted-fg        │
│ shadow-sm            │        │ cursor-not-allowed   │
└──────────────────────┘        └──────────────────────┘
```

---

## Responsive Breakpoints

```
MOBILE (< 768px)              TABLET (768-1023px)          DESKTOP (≥ 1024px)
┌─────────────────┐           ┌─────────────────────┐      ┌──────────────────────────────┐
│ Header          │           │ Header              │      │ Header                       │
├─────────────────┤           ├─────────────────────┤      ├──────────────────────────────┤
│                 │           │                     │      │                              │
│  Hero (4:3)     │           │   Hero (16:9)       │      │   Hero (21:9 ultra-wide)     │
│                 │           │                     │      │                              │
├─────────────────┤           ├─────────────────────┤      ├────────────────┬─────────────┤
│ Title           │           │ Title               │      │ Title          │ Sidebar     │
│ Host            │           │ Host                │      │ Host           │ (sticky)    │
│ Details         │           │ Details             │      │ Details        │             │
│ Reviews         │           │ Reviews             │      │ Reviews        │ $45         │
│ ...             │           │ ...                 │      │ ...            │ Calendar    │
│                 │           │                     │      │                │ [Reserve]   │
│                 │           │ [Booking Section]   │      │                │             │
│                 │           │ (full-width)        │      │                │ Trust       │
│                 │           │                     │      │                │ indicators  │
├─────────────────┤           └─────────────────────┘      └────────────────┴─────────────┘
│ $45 [Reserve]  │ ← Fixed                                  Grid: 2/3 + 1/3 columns
└─────────────────┘   bottom bar                            Sidebar: position: sticky
Single column         (appears on scroll)                   
```

---

## Token Inheritance Tree

```
:root (globals.css)
│
├─ Layout Tokens
│  ├─ --background ──────► bg-background (page canvas)
│  ├─ --card ──────────────► bg-card (containers)
│  ├─ --accent ────────────► bg-accent (hover states)
│  ├─ --muted ─────────────► bg-muted (disabled/loading)
│  └─ --border ────────────► border-border (all dividers)
│
├─ Typography Tokens
│  ├─ --foreground ────────► text-foreground (primary text)
│  ├─ --muted-foreground ──► text-muted-foreground (secondary)
│  └─ --card-foreground ───► text-card-foreground (on cards)
│
├─ Interactive Tokens
│  ├─ --primary ───────────► bg-primary (CTA buttons)
│  │                          hover: bg-primary/90
│  ├─ --primary-foreground ─► text-primary-foreground (CTA text)
│  └─ --ring ───────────────► focus-visible:ring-ring/50
│
├─ Status Tokens
│  ├─ --chart-1 ───────────► text-chart-1 (ratings ★, trust ✓)
│  ├─ --destructive ────────► text-destructive (errors ✕, delete 🗑)
│  └─ --secondary ──────────► bg-secondary (subtle highlights)
│
└─ Dark Mode (.dark)
   All tokens auto-swap via CSS variables
   └─ No manual dark: classes needed (unless opacity overlays)
```

---

## Before & After Comparison

```
BEFORE (Hardcoded Colors)          AFTER (Token-Based)
───────────────────────────────────────────────────────────────────
bg-white                    →      bg-card / bg-background
bg-gray-50                  →      bg-accent
bg-gray-100                 →      bg-muted
text-gray-600               →      text-muted-foreground
text-gray-900               →      text-foreground
border-gray-200             →      border-border
text-orange-400             →      text-chart-1
text-red-500                →      text-destructive
from-orange-500 to-rose-600 →      bg-primary (simplified)

DARK MODE: Broken              →   DARK MODE: Fully automatic
Manual dark:bg-gray-800        →   Tokens adapt automatically
50+ color definitions          →   12 semantic tokens
───────────────────────────────────────────────────────────────────
```

---

## Quick Copy-Paste Patterns

### Standard Button
```tsx
<Button className="bg-primary hover:bg-primary/90 active:scale-95 transition-all duration-300">
  Click Me
</Button>
```

### Date Picker Item
```tsx
<button className={`
  p-3 rounded-lg transition-all duration-300
  ${selected 
    ? 'bg-primary text-primary-foreground' 
    : 'bg-card border border-border hover:bg-accent hover:border-ring'
  }
  active:scale-95 focus-visible:ring-[3px] focus-visible:ring-ring/50
`}>
  Wed, Jan 15
</button>
```

### Card with Hover
```tsx
<div className="bg-card border border-border rounded-xl p-6 hover:shadow-xl hover:border-ring transition-all duration-300">
  Content
</div>
```

### Link
```tsx
<a className="text-foreground hover:text-primary transition-colors duration-200 underline-offset-4">
  Learn more →
</a>
```

### Loading Skeleton
```tsx
<div className="bg-muted animate-pulse rounded-lg h-40 w-full" />
```

---

## Accessibility Quick Checks

```
┌─────────────────────────────────────────────────────────────────────┐
│ WCAG AA COMPLIANCE CHECKLIST                                        │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│ ✅ Color Contrast                                                   │
│    • text-foreground on bg-background: 17.1:1 (AAA)                │
│    • text-muted-foreground on bg-background: 4.8:1 (AA)            │
│    • text-primary-foreground on bg-primary: 16.2:1 (AAA)           │
│                                                                     │
│ ✅ Keyboard Navigation                                              │
│    • All buttons/links focusable                                   │
│    • Focus-visible rings on all interactive elements               │
│    • Tab order follows visual hierarchy                            │
│                                                                     │
│ ✅ Screen Reader Support                                            │
│    • Semantic HTML (button, not div onClick)                       │
│    • Alt text on all images                                        │
│    • ARIA labels where text isn't visible                          │
│    • Status announcements (aria-live)                              │
│                                                                     │
│ ✅ Reduced Motion                                                   │
│    • Respects prefers-reduced-motion                               │
│    • Animations degrade gracefully                                 │
│                                                                     │
│ ✅ Touch Targets                                                    │
│    • Minimum 44x44px for all interactive elements                  │
│    • Adequate spacing between adjacent buttons                     │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

**This visual reference is your single source of truth for the Mayhouse design system.**

Keep it open while coding. When in doubt, reference these patterns.

**Last Updated**: January 2, 2026  
**Version**: 1.0.0
